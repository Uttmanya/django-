from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('assessment/', views.assessment, name='assessment'),
    path('results/', views.results, name='results'),
    path('support/', views.support, name='support'),
]

