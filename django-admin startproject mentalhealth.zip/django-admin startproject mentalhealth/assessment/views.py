from django.shortcuts import render

def home(request):
    """Home page with mental health assessment introduction"""
    return render(request, 'assessment/home.html')

def assessment(request):
    """Mental health assessment questionnaire page"""
    return render(request, 'assessment/assessment.html')

def results(request):
    """Results and guidance page (data comes from localStorage via JavaScript)"""
    return render(request, 'assessment/results.html')

def support(request):
    """Support resources page"""
    return render(request, 'assessment/support.html')

