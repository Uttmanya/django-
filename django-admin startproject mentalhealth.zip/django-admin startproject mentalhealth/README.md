# Mental Health Assessment Application

A Django-based web application for self-identifying mental health status and getting guidance for support. This application uses **localStorage** instead of a database to store assessment data, ensuring complete privacy.

## Features

- ✅ Self-assessment questionnaire (10 questions)
- ✅ LocalStorage for data storage (no database)
- ✅ Progress saving and auto-save
- ✅ Assessment results with personalized guidance
- ✅ Assessment history
- ✅ Support resources page
- ✅ Export assessment data
- ✅ Beautiful, modern UI

## Installation

1. Install Django:
```bash
pip install -r requirements.txt
```

2. Run migrations (optional, if needed):
```bash
python manage.py migrate
```

3. Run the development server:
```bash
python manage.py runserver
```

4. Open your browser and navigate to:
```
http://127.0.0.1:8000/
```

## Usage

1. **Home Page**: Introduction to the mental health assessment
2. **Assessment Page**: Answer 10 questions about your mental health
3. **Results Page**: View your assessment results and get personalized guidance
4. **Support Page**: Access mental health resources and view assessment history

## Data Storage

All assessment data is stored in the browser's localStorage, not in a database. This means:
- Your data stays private and local to your browser
- No server-side storage
- Data persists across sessions
- You can export your data as JSON

## Assessment Questions

The assessment covers:
1. Anxiety/Worry levels
2. Sleep quality
3. Sadness/Depression
4. Concentration
5. Energy levels
6. Feeling overwhelmed
7. Social relationships
8. Mood swings
9. Stress coping
10. Hope for the future

## Scoring

- Score 0-10: Excellent Mental Health
- Score 11-20: Good Mental Health
- Score 21-30: Moderate Concerns
- Score 31-40: High Concerns - Seek Professional Help

## Important Notes

- This application is **not a substitute for professional medical advice**
- If you are in crisis, please seek immediate professional help
- Crisis helplines are provided on the support page
- The assessment is for informational purposes only

## Technologies Used

- Django 4.2+
- HTML5/CSS3
- JavaScript (localStorage API)
- Font Awesome icons

## License

This project is for educational purposes.

