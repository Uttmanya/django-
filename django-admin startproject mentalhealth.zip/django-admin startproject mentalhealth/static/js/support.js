// Support page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    const historyContent = document.getElementById('historyContent');
    const clearHistoryBtn = document.getElementById('clearHistory');
    
    // Load assessment history
    loadHistory();
    
    // Clear history button
    if (clearHistoryBtn) {
        clearHistoryBtn.addEventListener('click', function() {
            if (confirm('Are you sure you want to clear your assessment history? This action cannot be undone.')) {
                clearHistory();
            }
        });
    }
    
    function loadHistory() {
        const history = JSON.parse(localStorage.getItem('assessment_history') || '[]');
        
        if (history.length === 0) {
            historyContent.innerHTML = '<p class="text-muted">No assessment history found. Complete an assessment to see your history here.</p>';
            return;
        }
        
        historyContent.innerHTML = '';
        
        // Reverse to show most recent first
        history.reverse().forEach((assessment, index) => {
            const historyItem = document.createElement('div');
            historyItem.className = 'history-item';
            
            const date = new Date(assessment.timestamp);
            const dateStr = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
            
            let status = '';
            if (assessment.score <= 10) {
                status = 'Excellent';
            } else if (assessment.score <= 20) {
                status = 'Good';
            } else if (assessment.score <= 30) {
                status = 'Moderate';
            } else {
                status = 'High Concerns';
            }
            
            historyItem.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <strong>Assessment #${history.length - index}</strong>
                        <p style="margin: 0.5rem 0 0 0; color: #666;">Date: ${dateStr}</p>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-size: 1.5rem; font-weight: bold; color: #667eea;">${assessment.score}/40</div>
                        <div style="color: #666;">${status}</div>
                    </div>
                </div>
            `;
            
            historyContent.appendChild(historyItem);
        });
    }
    
    function clearHistory() {
        localStorage.removeItem('assessment_history');
        localStorage.removeItem('assessment_result');
        localStorage.removeItem('assessment_answers');
        localStorage.removeItem('assessment_timestamp');
        
        historyContent.innerHTML = '<p class="text-muted">History cleared. Complete an assessment to see your history here.</p>';
        
        alert('Assessment history cleared successfully.');
    }
});

