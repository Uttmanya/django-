// Assessment JavaScript with localStorage functionality

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('assessmentForm');
    const saveProgressBtn = document.getElementById('saveProgress');
    const progressFill = document.getElementById('progressFill');
    
    // Load saved progress from localStorage
    loadSavedProgress();
    
    // Update progress bar
    updateProgressBar();
    
    // Save progress button
    if (saveProgressBtn) {
        saveProgressBtn.addEventListener('click', function() {
            saveProgress();
            showNotification('Progress saved!', 'success');
        });
    }
    
    // Auto-save on change
    form.addEventListener('change', function() {
        saveProgress();
        updateProgressBar();
    });
    
    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        submitAssessment();
    });
    
    // Function to save progress to localStorage
    function saveProgress() {
        const formData = new FormData(form);
        const answers = {};
        
        // Get all radio button values
        const questions = ['anxiety', 'sleep', 'depression', 'concentration', 'energy', 
                          'overwhelmed', 'social', 'mood', 'stress', 'hope'];
        
        questions.forEach(question => {
            const value = formData.get(question);
            if (value !== null) {
                answers[question] = parseInt(value);
            }
        });
        
        // Save to localStorage
        localStorage.setItem('assessment_answers', JSON.stringify(answers));
        localStorage.setItem('assessment_timestamp', new Date().toISOString());
    }
    
    // Function to load saved progress from localStorage
    function loadSavedProgress() {
        const savedAnswers = localStorage.getItem('assessment_answers');
        
        if (savedAnswers) {
            const answers = JSON.parse(savedAnswers);
            
            // Restore radio button selections
            Object.keys(answers).forEach(question => {
                const value = answers[question];
                const radio = form.querySelector(`input[name="${question}"][value="${value}"]`);
                if (radio) {
                    radio.checked = true;
                }
            });
        }
    }
    
    // Function to update progress bar
    function updateProgressBar() {
        const formData = new FormData(form);
        const questions = ['anxiety', 'sleep', 'depression', 'concentration', 'energy', 
                          'overwhelmed', 'social', 'mood', 'stress', 'hope'];
        
        let answered = 0;
        questions.forEach(question => {
            if (formData.get(question) !== null) {
                answered++;
            }
        });
        
        const progress = (answered / questions.length) * 100;
        progressFill.style.width = progress + '%';
    }
    
    // Function to submit assessment
    function submitAssessment() {
        const formData = new FormData(form);
        const questions = ['anxiety', 'sleep', 'depression', 'concentration', 'energy', 
                          'overwhelmed', 'social', 'mood', 'stress', 'hope'];
        
        let allAnswered = true;
        questions.forEach(question => {
            if (formData.get(question) === null) {
                allAnswered = false;
            }
        });
        
        if (!allAnswered) {
            alert('Please answer all questions before submitting.');
            return;
        }
        
        // Calculate score
        let totalScore = 0;
        questions.forEach(question => {
            totalScore += parseInt(formData.get(question));
        });
        
        // Save final assessment
        saveProgress();
        
        // Save assessment result
        const assessmentResult = {
            score: totalScore,
            maxScore: 40,
            answers: {},
            timestamp: new Date().toISOString()
        };
        
        questions.forEach(question => {
            assessmentResult.answers[question] = parseInt(formData.get(question));
        });
        
        // Save to localStorage
        localStorage.setItem('assessment_result', JSON.stringify(assessmentResult));
        
        // Save to history
        saveToHistory(assessmentResult);
        
        // Redirect to results page
        window.location.href = '/results/';
    }
    
    // Function to save to history
    function saveToHistory(assessmentResult) {
        let history = JSON.parse(localStorage.getItem('assessment_history') || '[]');
        history.push(assessmentResult);
        
        // Keep only last 10 assessments
        if (history.length > 10) {
            history = history.slice(-10);
        }
        
        localStorage.setItem('assessment_history', JSON.stringify(history));
    }
    
    // Function to show notification
    function showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#28a745' : '#dc3545'};
            color: white;
            padding: 1rem 2rem;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            z-index: 1000;
            animation: slideIn 0.3s;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 2000);
    }
});

