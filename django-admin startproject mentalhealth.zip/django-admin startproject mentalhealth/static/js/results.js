// Results JavaScript - reads from localStorage

document.addEventListener('DOMContentLoaded', function() {
    const resultsContent = document.getElementById('resultsContent');
    const resultsDisplay = document.getElementById('resultsDisplay');
    const noResults = document.getElementById('noResults');
    
    // Load results from localStorage
    loadResults();
    
    // Export data button
    const exportBtn = document.getElementById('exportData');
    if (exportBtn) {
        exportBtn.addEventListener('click', exportData);
    }
    
    function loadResults() {
        const assessmentResult = localStorage.getItem('assessment_result');
        
        if (!assessmentResult) {
            resultsContent.style.display = 'none';
            noResults.style.display = 'block';
            return;
        }
        
        const result = JSON.parse(assessmentResult);
        
        // Hide loading, show results
        resultsContent.style.display = 'none';
        resultsDisplay.style.display = 'block';
        
        // Display score
        const scoreValue = document.getElementById('scoreValue');
        const scoreStatus = document.getElementById('scoreStatus');
        const breakdownContent = document.getElementById('breakdownContent');
        const guidanceContent = document.getElementById('guidanceContent');
        
        if (scoreValue) {
            scoreValue.textContent = result.score;
        }
        
        // Determine status
        let status = '';
        let statusClass = '';
        let guidance = [];
        
        if (result.score <= 10) {
            status = 'Excellent Mental Health';
            statusClass = 'excellent';
            guidance = getGuidance('excellent');
        } else if (result.score <= 20) {
            status = 'Good Mental Health';
            statusClass = 'good';
            guidance = getGuidance('good');
        } else if (result.score <= 30) {
            status = 'Moderate Concerns';
            statusClass = 'moderate';
            guidance = getGuidance('moderate');
        } else {
            status = 'High Concerns - Seek Professional Help';
            statusClass = 'high';
            guidance = getGuidance('high');
        }
        
        if (scoreStatus) {
            scoreStatus.textContent = status;
            scoreStatus.className = `score-status ${statusClass}`;
        }
        
        // Display breakdown
        if (breakdownContent) {
            breakdownContent.innerHTML = '';
            const questionLabels = {
                anxiety: 'Anxiety/Worry',
                sleep: 'Sleep Quality',
                depression: 'Sadness/Depression',
                concentration: 'Concentration',
                energy: 'Energy Level',
                overwhelmed: 'Feeling Overwhelmed',
                social: 'Social Relationships',
                mood: 'Mood Swings',
                stress: 'Stress Coping',
                hope: 'Hope for Future'
            };
            
            Object.keys(result.answers).forEach(key => {
                const item = document.createElement('div');
                item.className = 'breakdown-item';
                const value = result.answers[key];
                const label = questionLabels[key] || key;
                const level = getLevel(value);
                
                item.innerHTML = `
                    <strong>${label}:</strong> ${level} (${value}/4)
                `;
                breakdownContent.appendChild(item);
            });
        }
        
        // Display guidance
        if (guidanceContent) {
            guidanceContent.innerHTML = '';
            guidance.forEach(item => {
                const guidanceItem = document.createElement('div');
                guidanceItem.className = 'guidance-item';
                guidanceItem.innerHTML = `
                    <h4><i class="fas ${item.icon}"></i> ${item.title}</h4>
                    <p>${item.description}</p>
                `;
                guidanceContent.appendChild(guidanceItem);
            });
        }
    }
    
    function getLevel(value) {
        if (value === 0) return 'Excellent';
        if (value === 1) return 'Good';
        if (value === 2) return 'Moderate';
        if (value === 3) return 'Poor';
        return 'Very Poor';
    }
    
    function getGuidance(level) {
        const guidanceMap = {
            excellent: [
                {
                    icon: 'fa-check-circle',
                    title: 'Maintain Your Wellness',
                    description: 'You are doing great! Continue practicing self-care and maintaining healthy habits.'
                },
                {
                    icon: 'fa-heart',
                    title: 'Keep Balanced',
                    description: 'Maintain a balanced lifestyle with regular exercise, healthy sleep, and social connections.'
                }
            ],
            good: [
                {
                    icon: 'fa-smile',
                    title: 'Stay Positive',
                    description: 'Your mental health is in good shape. Continue practicing mindfulness and self-care.'
                },
                {
                    icon: 'fa-walking',
                    title: 'Maintain Healthy Habits',
                    description: 'Regular exercise, good sleep, and social connections are key to maintaining mental wellness.'
                }
            ],
            moderate: [
                {
                    icon: 'fa-user-md',
                    title: 'Consider Professional Help',
                    description: 'It may be beneficial to speak with a mental health professional. Consider therapy or counseling.'
                },
                {
                    icon: 'fa-spa',
                    title: 'Practice Self-Care',
                    description: 'Focus on self-care activities like meditation, exercise, and hobbies. Take time for yourself.'
                },
                {
                    icon: 'fa-users',
                    title: 'Stay Connected',
                    description: 'Maintain social connections with friends and family. Don\'t hesitate to reach out for support.'
                }
            ],
            high: [
                {
                    icon: 'fa-exclamation-triangle',
                    title: 'Seek Professional Help Immediately',
                    description: 'Please consider seeking help from a mental health professional. Therapy, counseling, or psychiatric care can be very beneficial.'
                },
                {
                    icon: 'fa-phone',
                    title: 'Crisis Support',
                    description: 'If you are in crisis, please reach out immediately: National Suicide Prevention Lifeline: 988, Crisis Text Line: Text HOME to 741741, Emergency: 911'
                },
                {
                    icon: 'fa-hands-helping',
                    title: 'Support Systems',
                    description: 'Reach out to friends, family, or support groups. You don\'t have to go through this alone.'
                },
                {
                    icon: 'fa-leaf',
                    title: 'Self-Care is Essential',
                    description: 'Practice self-care, but remember that professional help is often necessary for more serious concerns.'
                }
            ]
        };
        
        return guidanceMap[level] || guidanceMap.moderate;
    }
    
    function exportData() {
        const assessmentResult = localStorage.getItem('assessment_result');
        if (!assessmentResult) {
            alert('No assessment data to export.');
            return;
        }
        
        const result = JSON.parse(assessmentResult);
        const dataStr = JSON.stringify(result, null, 2);
        const dataBlob = new Blob([dataStr], {type: 'application/json'});
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `mental-health-assessment-${new Date().toISOString().split('T')[0]}.json`;
        link.click();
        URL.revokeObjectURL(url);
    }
});

